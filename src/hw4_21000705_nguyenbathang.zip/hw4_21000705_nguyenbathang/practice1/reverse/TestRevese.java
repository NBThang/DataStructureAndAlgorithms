package hw4_21000705_nguyenbathang.practice1.reverse;

public class TestRevese {
    public static void main(String[] args) {
        ReverseString reverseString = new ReverseString();
        System.out.println("revese of 'codelearn' is: " + reverseString.reverseString("codelearn"));
        System.out.println("revese of 'nguyenbathang' is: " + reverseString.reverseString("nguyenbathang"));
    }
}
