package hw6_21000705_nguyenbathang.ex1.interface_ex1;

public interface Entry <K,E> {
    K getKey();
    E getValue();
}
